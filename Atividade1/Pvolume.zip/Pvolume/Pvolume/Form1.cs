﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume; // Variáveis globais

        public Form1()
        {
            InitializeComponent();
        }


        // validação de dados
        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtRaio.Text, out raio) || (raio <= 0))
            {
                MessageBox.Show("Digite um valor válido.");
                txtRaio.Focus();
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Digite um valor válido.");
                txtAltura.Focus();
            }
        }

        // eventos de click
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtRaio.Clear();
            txtVolume.Clear();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            volume = Math.PI * Math.Pow(raio, 2) * altura;
            txtVolume.Text = volume.ToString();
        }


        private void txtRaio_TextChanged(object sender, EventArgs e)
        {
            double.TryParse(txtRaio.Text, out raio);
        }
        private void txtAltura_TextChanged(object sender, EventArgs e)
        {
            double.TryParse(txtAltura.Text, out altura);
        }
    }
}
