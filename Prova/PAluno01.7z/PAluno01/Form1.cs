﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Eventos click
        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBoxNotas.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {

            Double[,] alunosNotas = new Double[5, 3];
            string auxiliar = "";


            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Professor {j + 1}, Digite a nota do aluno {i + 1}", "Entrada de Dados");

                    if (!double.TryParse(auxiliar, out alunosNotas[i, j]) ||
                        alunosNotas[i, j] > 10 ||
                        alunosNotas[i, j] < 0
                        )
                    {
                        MessageBox.Show("Nota inválida");
                        j--;
                    }

                    if (auxiliar == "")
                    {
                        break;
                    }
                }
            }

            ArrayList notasFinais1 = new ArrayList();

                double mediaSala = 0.0;

            for (int k = 0; k < 5; k++)
            {
                notasFinais1.Add($"Aluno {k + 1}: " +
                $"Nota professor 1: {alunosNotas[k, 0].ToString("F2")} " +
                $"Nota professor 2: {alunosNotas[k, 1].ToString("F2")} " +
                $"Nota professor 3: {alunosNotas[k, 2].ToString("F2")} " +
                $"Média: {(((alunosNotas[k, 0]) + (alunosNotas[k, 1]) + (alunosNotas[k, 2])) / 3).ToString("F2")}\n\n");
                
                mediaSala += (((alunosNotas[k, 0]) + (alunosNotas[k, 1]) + (alunosNotas[k, 2])) / 3);

                listBoxNotas.Items.Add(notasFinais1[k]);
            }

            listBoxNotas.Items.Add("Média da sala:" + (mediaSala / 5).ToString());

        }

    }
}
