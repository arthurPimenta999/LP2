﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica_Lp2_Aula6
{
    public partial class Exercicio4 : Form
    {
        public Exercicio4()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtGratificacao.Clear();
            txtSalario.Clear();
            txtMatricula.Clear();
            txtNome.Clear();
            txtProducao.Clear();
        }

        private void btnCalcularSalario_Click(object sender, EventArgs e)
        {
            double salarioBruto, gratificacao;
            double A, B, C, D;
            int producao;

            A = double.Parse(txtSalario.Text);
            producao = int.Parse(txtProducao.Text);
            gratificacao = double.Parse(txtGratificacao.Text);

            B = 0.0;
            C = 0.0;
            D = 0.0;

            if (producao >= 100)
            {
                B = 1;
            } else if (producao >= 120)
            {
                B = 1;
                C = 1;
            }
            else if (producao >= 150)
            {
                B = 1;
                C = 1;
                D = 1;
            }

            salarioBruto = A + A * ((0.05 * B) + (0.1 * C) + (0.1 * D)) + gratificacao;

            if(producao >= 100 && gratificacao<0)
            {
                txtSalarioBruto.Text = salarioBruto.ToString("C");
            }
            else
            {
                txtSalarioBruto.Text = 7000.ToString("C");
            }

        }
    }
}
