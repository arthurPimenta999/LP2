﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica_Lp2_Aula6
{
    public partial class Exercicio3 : Form
    {
        public Exercicio3()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtIsPalindromo.Text = "";
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string palavra = new string(txtIsPalindromo.Text.ToUpper().ToArray());
            string palavraInvertida = new string(palavra.ToUpper().Reverse().ToArray());

            if (palavra == palavraInvertida)
            {
                MessageBox.Show("É um palíndromo");
            }
            else
            {
                MessageBox.Show("Não é um palíndromo");
            }
        }
    }
}
