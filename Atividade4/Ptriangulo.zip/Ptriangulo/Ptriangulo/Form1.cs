﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC;

        public Form1()
        {
            InitializeComponent();
        }

        // ===== validações =====

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtValorA.Text, out double valor) ||
                valor == 0 ||
                string.IsNullOrWhiteSpace(txtValorA.Text))
            {
                MessageBox.Show("Valor inválido");
                txtValorA.Focus();
            }

        }
        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorB.Text, out double valor) ||
                valor == 0 ||
                string.IsNullOrWhiteSpace(txtValorB.Text))
            {
                MessageBox.Show("Valor inválido");
                txtValorB.Focus();
            }

        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorC.Text, out double valor) || 
                valor == 0 || 
                string.IsNullOrWhiteSpace(txtValorC.Text))
            {
                MessageBox.Show("Valor inválido");
                txtValorC.Focus();
            }

        }

        // ===== botões =====

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }


        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double.TryParse(txtValorA.Text, out double valorA);
            double.TryParse(txtValorB.Text, out double valorB);
            double.TryParse(txtValorC.Text, out double valorC);

            if (valorA == valorB && valorB == valorC)
            {
                txtTriangulo.Text = "Equilátero";
            }
            else if (valorA == valorB || valorA == valorC || valorB == valorC)
            {
                txtTriangulo.Text = "Isósceles";
            }
            else
            {
                txtTriangulo.Text = "Escaleno";
            }
        }
        
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Text = "";
            txtValorB.Text = "";
            txtValorC.Text = "";
            txtTriangulo.Text = "";
        }
    }
}
