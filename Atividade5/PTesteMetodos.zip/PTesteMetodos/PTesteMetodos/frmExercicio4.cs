﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnIsNumber_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contNum = 0;

            while (contador < rchTxtFrase.Text.Length)
            {
                if (char.IsNumber(rchTxtFrase.Text[contador]))
                {
                    contNum++;
                }
                contador++;
            }

            MessageBox.Show($"O texto contém {contNum} caracteres numéricos.");
        }

        private void btnAcharVazio_Click(object sender, EventArgs e)
        {
            int contador = 0;

            while (contador < rchTxtFrase.Text.Length)
            {
                if (char.IsWhiteSpace(rchTxtFrase.Text[contador]))
                {
                    MessageBox.Show($"O primeiro espaço em branco está na posição {contador}");
                    break;
                }
                contador++;
            }
        }

        private void btnIsLetter_Click(object sender, EventArgs e)
        {
            string texto = rchTxtFrase.Text;
            int contLetras = 0;

            foreach (char c in texto)
            {
                if (char.IsLetter(c))
                { 
                    contLetras++;
                }
            }
            MessageBox.Show($"O texto contém {contLetras} letras.");
        }
    }
}
