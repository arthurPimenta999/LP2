﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            if (string.Compare(txtPalavra1.Text, txtPalavra2.Text) == 0)
            {
                MessageBox.Show("As palavras são iguais");
            }
            else
            {
                MessageBox.Show("As palavras são diferentes");
            }
        }

        private void btnIgualarTextos_Click(object sender, EventArgs e)
        {
            txtPalavra2.Text = "";
            string texto1 = txtPalavra1.Text;
            string texto2 = txtPalavra2.Text;
            int meio = texto2.Length / 2;
            string resultado = texto2.Insert(meio, texto1);
            txtPalavra2.Text = resultado;
        }

        private void btnInserirAsterisco_Click(object sender, EventArgs e)
        {
            string texto1 = txtPalavra1.Text;
            int meio = texto1.Length / 2;
            string resultado = texto1.Insert(meio, "**");
            txtPalavra2.Text = resultado;
        }
    }
}
