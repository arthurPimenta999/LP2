﻿namespace PTesteMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnEspelhar = new System.Windows.Forms.Button();
            this.btnRemover1do2 = new System.Windows.Forms.Button();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnEspelhar);
            this.groupBox1.Controls.Add(this.btnRemover1do2);
            this.groupBox1.Controls.Add(this.txtPalavra2);
            this.groupBox1.Controls.Add(this.txtPalavra1);
            this.groupBox1.Controls.Add(this.lblPalavra2);
            this.groupBox1.Controls.Add(this.lblPalavra1);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(738, 443);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Terceiro";
            // 
            // btnEspelhar
            // 
            this.btnEspelhar.BackColor = System.Drawing.Color.Black;
            this.btnEspelhar.Location = new System.Drawing.Point(427, 377);
            this.btnEspelhar.Name = "btnEspelhar";
            this.btnEspelhar.Size = new System.Drawing.Size(134, 46);
            this.btnEspelhar.TabIndex = 5;
            this.btnEspelhar.Text = "Espelhar";
            this.btnEspelhar.UseVisualStyleBackColor = false;
            this.btnEspelhar.Click += new System.EventHandler(this.btnEspelhar_Click);
            // 
            // btnRemover1do2
            // 
            this.btnRemover1do2.BackColor = System.Drawing.Color.Black;
            this.btnRemover1do2.Location = new System.Drawing.Point(587, 377);
            this.btnRemover1do2.Name = "btnRemover1do2";
            this.btnRemover1do2.Size = new System.Drawing.Size(134, 46);
            this.btnRemover1do2.TabIndex = 4;
            this.btnRemover1do2.Text = "Remover 1 do 2";
            this.btnRemover1do2.UseVisualStyleBackColor = false;
            this.btnRemover1do2.Click += new System.EventHandler(this.btnRemover1do2_Click);
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(126, 117);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(286, 24);
            this.txtPalavra2.TabIndex = 3;
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(126, 49);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(286, 24);
            this.txtPalavra1.TabIndex = 2;
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(35, 120);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(74, 19);
            this.lblPalavra2.TabIndex = 1;
            this.lblPalavra2.Text = "Palavra 2";
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(35, 52);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(74, 19);
            this.lblPalavra1.TabIndex = 0;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(762, 467);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmExercicio3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmExercicio3";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnEspelhar;
        private System.Windows.Forms.Button btnRemover1do2;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.Label lblPalavra1;
    }
}