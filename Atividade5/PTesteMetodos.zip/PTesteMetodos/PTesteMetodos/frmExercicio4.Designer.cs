﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAcharVazio = new System.Windows.Forms.Button();
            this.btnIsNumber = new System.Windows.Forms.Button();
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.rchTxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnIsLetter = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnIsLetter);
            this.groupBox1.Controls.Add(this.rchTxtFrase);
            this.groupBox1.Controls.Add(this.btnAcharVazio);
            this.groupBox1.Controls.Add(this.btnIsNumber);
            this.groupBox1.Controls.Add(this.lblPalavra1);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(738, 443);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Quarto";
            // 
            // btnAcharVazio
            // 
            this.btnAcharVazio.BackColor = System.Drawing.Color.Black;
            this.btnAcharVazio.Location = new System.Drawing.Point(427, 377);
            this.btnAcharVazio.Name = "btnAcharVazio";
            this.btnAcharVazio.Size = new System.Drawing.Size(134, 46);
            this.btnAcharVazio.TabIndex = 5;
            this.btnAcharVazio.Text = "Achar espaço vazio";
            this.btnAcharVazio.UseVisualStyleBackColor = false;
            this.btnAcharVazio.Click += new System.EventHandler(this.btnAcharVazio_Click);
            // 
            // btnIsNumber
            // 
            this.btnIsNumber.BackColor = System.Drawing.Color.Black;
            this.btnIsNumber.Location = new System.Drawing.Point(587, 377);
            this.btnIsNumber.Name = "btnIsNumber";
            this.btnIsNumber.Size = new System.Drawing.Size(134, 46);
            this.btnIsNumber.TabIndex = 4;
            this.btnIsNumber.Text = "Verificar Char. Numéricos";
            this.btnIsNumber.UseVisualStyleBackColor = false;
            this.btnIsNumber.Click += new System.EventHandler(this.btnIsNumber_Click);
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(35, 52);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(73, 19);
            this.lblPalavra1.TabIndex = 0;
            this.lblPalavra1.Text = "Seu Texto";
            // 
            // rchTxtFrase
            // 
            this.rchTxtFrase.Location = new System.Drawing.Point(125, 49);
            this.rchTxtFrase.Name = "rchTxtFrase";
            this.rchTxtFrase.Size = new System.Drawing.Size(246, 164);
            this.rchTxtFrase.TabIndex = 6;
            this.rchTxtFrase.Text = "";
            // 
            // btnIsLetter
            // 
            this.btnIsLetter.BackColor = System.Drawing.Color.Black;
            this.btnIsLetter.Location = new System.Drawing.Point(271, 377);
            this.btnIsLetter.Name = "btnIsLetter";
            this.btnIsLetter.Size = new System.Drawing.Size(134, 46);
            this.btnIsLetter.TabIndex = 7;
            this.btnIsLetter.Text = "Verificar Char. Alfabéticos";
            this.btnIsLetter.UseVisualStyleBackColor = false;
            this.btnIsLetter.Click += new System.EventHandler(this.btnIsLetter_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(762, 467);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmExercicio4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmExercicio4";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnAcharVazio;
        private System.Windows.Forms.Button btnIsNumber;
        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.RichTextBox rchTxtFrase;
        private System.Windows.Forms.Button btnIsLetter;
    }
}